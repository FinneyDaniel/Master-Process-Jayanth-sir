
/***safety_fault_detection_testing.c***/

1.check the hw_fnCANtranscheck - CAN transceiver GPIO pin
2. HW_fnReset() check 
3.check the heart beat gpio HW_fnDSP_beat() cgpio configuration pending
