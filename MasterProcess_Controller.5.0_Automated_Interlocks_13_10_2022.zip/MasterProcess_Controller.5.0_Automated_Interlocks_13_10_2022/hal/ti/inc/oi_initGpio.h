/*
 * oi_initGpio.h
 *
 *  Created on: Oct 9, 2020
 *      Author: enArka
 */

#ifndef INCLUDE_OI_INITGPIO_H_
#define INCLUDE_OI_INITGPIO_H_


#define DISABLE_PULLUP          1
#define ENABLE_PULLUP           0

#define OUTPUT_PIN              1
#define INPUT_PIN               0

#define EPWM_FUNCTION           1
#define GPIO_FUNCTION           0


#endif /* INCLUDE_OI_INITGPIO_H_ */
